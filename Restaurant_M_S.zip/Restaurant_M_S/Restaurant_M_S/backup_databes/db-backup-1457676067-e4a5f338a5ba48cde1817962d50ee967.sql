DROP TABLE companey;

CREATE TABLE `companey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(45) COLLATE utf32_persian_ci NOT NULL,
  `address` varchar(45) COLLATE utf32_persian_ci NOT NULL,
  `email` varchar(45) CHARACTER SET ucs2 COLLATE ucs2_bin NOT NULL,
  `phone` varchar(20) COLLATE utf32_persian_ci NOT NULL,
  `cpreamble` varchar(45) COLLATE utf32_persian_ci NOT NULL,
  UNIQUE KEY `id` (`id`,`address`,`cpreamble`),
  UNIQUE KEY `id_2` (`id`,`address`,`cpreamble`),
  UNIQUE KEY `phone` (`phone`),
  UNIQUE KEY `phone_2` (`phone`),
  UNIQUE KEY `phone_3` (`phone`),
  UNIQUE KEY `phone_4` (`phone`),
  UNIQUE KEY `phone_5` (`phone`),
  UNIQUE KEY `phone_6` (`phone`),
  UNIQUE KEY `phone_7` (`phone`),
  KEY `cname` (`address`,`cpreamble`),
  KEY `id_3` (`id`),
  KEY `address` (`address`),
  KEY `cpreamble` (`cpreamble`),
  KEY `id_4` (`id`,`address`,`cpreamble`),
  KEY `id_5` (`id`,`address`,`cpreamble`),
  KEY `id_6` (`id`,`address`,`cpreamble`),
  KEY `id_7` (`id`,`address`,`cpreamble`),
  KEY `id_8` (`id`,`address`,`cpreamble`),
  KEY `cname_2` (`cname`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf32 COLLATE=utf32_persian_ci;

INSERT INTO companey VALUES("3","super cola ","Herat_Afghanistan","Super@yahoo.com","987656","third contract");
INSERT INTO companey VALUES("4","برادران افغان","sadjj","afghan@yahoo.com","0799999999","second contract");
INSERT INTO companey VALUES("6","NIma","Herat-Sharak Sanatiy","Nima_info@gmai.com","799345345","first_companey for rob");
INSERT INTO companey VALUES("7","Pomtich","Herat","pom44@yahoo.com","790132125","ok");



DROP TABLE contract;

CREATE TABLE `contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(11) COLLATE utf8_persian_ci NOT NULL,
  `name` varchar(32) COLLATE utf8_persian_ci NOT NULL,
  `companyname` varchar(32) COLLATE utf8_persian_ci NOT NULL,
  `stamp` varchar(32) COLLATE utf8_persian_ci NOT NULL,
  `date` date NOT NULL,
  `preamble` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `stamp` (`stamp`),
  UNIQUE KEY `name` (`name`),
  KEY `id` (`id`,`name`,`companyname`,`date`,`preamble`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO contract VALUES("90","2435245","til","super cola","gause dfaqfa","0000-00-00","fadsgadgad");
INSERT INTO contract VALUES("92","1234","number1","برادران افغان","نوشابه ","2016-02-12","");
INSERT INTO contract VALUES("95","12345433","number3","super cola","نان","2016-02-11","dfladfadfakdnvcdafkja<br>dfadfadsfadfadfas<br>adfaddfadfadfas<br>");
INSERT INTO contract VALUES("108","0","rob","NIma","rob","2016-03-01","");
INSERT INTO contract VALUES("109","93","Ahmad","super cola","cola","2016-03-10","grate");
INSERT INTO contract VALUES("113","1245","sorab","super cola","clodth","2016-03-04","nice");



DROP TABLE contract_payment;

CREATE TABLE `contract_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `c_name` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `totalmoney` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `payment` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `description` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO contract_payment VALUES("4","2016-03-01","number3","500","500","all payed");
INSERT INTO contract_payment VALUES("5","2016-03-01","number1","12000","1000","");
INSERT INTO contract_payment VALUES("6","2016-03-01","rob","200","200","");



DROP TABLE food;

CREATE TABLE `food` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `salary` int(11) NOT NULL,
  `type` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `information` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `date` date NOT NULL,
  `image` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `description` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO food VALUES("15","beefburger","150","","high beer burger","2016-02-20","beefburger.jpg","salary for beer burger 10% decrease  ");
INSERT INTO food VALUES("16","bolani ","50","","bolani with souses ","2016-02-20","bolani.jpg","bolani with souses 50AF");
INSERT INTO food VALUES("17","coffee ","20","","one class of coffee 20AF","2016-02-21","coffee.jpg","");
INSERT INTO food VALUES("18","tea","20","","one glass with two chaklit ","2016-02-22","tea.jpg","");
INSERT INTO food VALUES("19","chips","50","","good new chips.","2016-02-22","chips.jpg","new chips .");
INSERT INTO food VALUES("20","chickenleg","300","","once ","2016-02-23","chickenleg.jpg","");
INSERT INTO food VALUES("21","Pizzza","20","","","0000-00-00","pizza.png","");
INSERT INTO food VALUES("22","kabab sekhi","100","Kabab","sekhi 10 afghani","2016-02-01","Click (50).jpg","");
INSERT INTO food VALUES("23","chalo rice","100","rice","100 one khorak","2016-02-29","Click (92).jpg","");
INSERT INTO food VALUES("24","kachery land","500","rice","delicios","2016-03-03","chickenpopcorn.jpg","");
INSERT INTO food VALUES("25","kobida","250","kabab","surkh","2016-03-03","chococake.jpg","");
INSERT INTO food VALUES("26","juce","100","drink","orenje","2016-03-03","icecream.jpg","");
INSERT INTO food VALUES("27","vanila","300","icecrim"," with out crim","2016-03-03","icecream.jpg","");
INSERT INTO food VALUES("28","juce","50","drink","orenje","2016-03-03","IMG_1068.jpg","");
INSERT INTO food VALUES("29","vanila","100","drink","orenje","2016-03-03","","");
INSERT INTO food VALUES("30","vanila","300","icecrim","surkh","2016-03-03","icecream.jpg","");



DROP TABLE i_spend;

CREATE TABLE `i_spend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `date` date NOT NULL,
  `salary` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `info` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO i_spend VALUES("4","gas","2016-03-01","200","");
INSERT INTO i_spend VALUES("5","til","2016-03-01","300","");
INSERT INTO i_spend VALUES("6","other","2016-03-01","500","");
INSERT INTO i_spend VALUES("7","keeper","2016-03-01","500","");



DROP TABLE login;

CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `password` (`password`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO login VALUES("96","ali","b7b975da6a95a9e891efad76d30b43b75a267911","nazirahmad123@gmai.con");
INSERT INTO login VALUES("97","nazirahmad7340","a345337cac6f04d611ded9dfe5488665ebdd7db6","nazirahmad7340@gmail.com");
INSERT INTO login VALUES("99","admin","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","admin@gmil.com");



DROP TABLE personnel;

CREATE TABLE `personnel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `part` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `name` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `lname` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `salary` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `date` date NOT NULL,
  `phone` varchar(32) COLLATE utf8_persian_ci DEFAULT NULL,
  `image` text COLLATE utf8_persian_ci NOT NULL,
  `description` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO personnel VALUES("18","restaurant","NazirAhmad","Parsa","5000","2016-02-01","0795997340","IMG_0211.JPG","Employee");
INSERT INTO personnel VALUES("19","restaurant","AB.Raman","Mohmmadi","5000","2016-02-01","07939999","IMG_0172.JPG","Employee");
INSERT INTO personnel VALUES("20","restaurant","Nair","AhmadQasimi","5000","2016-02-01","0795999994","Click (53).jpg","Employee");
INSERT INTO personnel VALUES("21","wash","karim","ahmady","5000","2016-03-02","0794528180","","");



DROP TABLE salary_payment;

CREATE TABLE `salary_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `id_personnel` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO salary_payment VALUES("96","5000","18","2016-03-01","first payment");
INSERT INTO salary_payment VALUES("97","5000","19","2016-03-01","first payment");
INSERT INTO salary_payment VALUES("98","5000","20","2016-03-01","first payment");



DROP TABLE salses;

CREATE TABLE `salses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_food` int(11) NOT NULL,
  `price` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=605 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO salses VALUES("586","30","1500");
INSERT INTO salses VALUES("587","28","1000");
INSERT INTO salses VALUES("588","27","3000");
INSERT INTO salses VALUES("589","24","1500");
INSERT INTO salses VALUES("590","22","5000");
INSERT INTO salses VALUES("591","25","10000");
INSERT INTO salses VALUES("592","23","1500");
INSERT INTO salses VALUES("593","24","10000");
INSERT INTO salses VALUES("594","28","100");
INSERT INTO salses VALUES("595","28","50");
INSERT INTO salses VALUES("596","26","100");
INSERT INTO salses VALUES("597","24","500");
INSERT INTO salses VALUES("598","22","100");
INSERT INTO salses VALUES("599","22","100");
INSERT INTO salses VALUES("600","29","100");
INSERT INTO salses VALUES("601","22","200");
INSERT INTO salses VALUES("602","22","200");
INSERT INTO salses VALUES("603","21","100");
INSERT INTO salses VALUES("604","30","10200");



DROP TABLE staple;

CREATE TABLE `staple` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_c` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `type` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `date` date NOT NULL,
  `kind` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `weight` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `price` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `money` varchar(45) COLLATE utf8_persian_ci NOT NULL,
  `info` text COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO staple VALUES("23","number1","else","2016-03-01","نوشابه ","100","120","12000","first recipt");
INSERT INTO staple VALUES("24","number3","else","2016-03-01","نان","50","10","500","");
INSERT INTO staple VALUES("25","rob","else","2016-03-01","rob","1","200","200","");



