<?php
	require_once('connection.php');
	if(isset($_POST['amount'])){
        $name = $_POST['amount'];
		
		$data = mysqli_query($link,"SELECT * FROM contract WHERE name='$name'");
		$get_stamp = mysqli_fetch_assoc($data);
		echo $get_stamp['stamp'];
	}
	
	
	
if(isset($_GET['count'])){
	$name = $_GET['count'];
	$count="not staple saved!";
	$data = mysqli_query($link,"SELECT * FROM staple WHERE name_c='$name'");
	while($get_stamp = mysqli_fetch_assoc($data)){
		$count=$get_stamp['money']+$count;
	}
	echo $count;
	}
?>