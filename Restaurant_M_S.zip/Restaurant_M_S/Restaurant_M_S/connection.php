﻿
<?php

	$localhost = "localhost";
	$root  = "root";
	$pass  = "";

	$link = mysqli_connect($localhost,$root,$pass,"restaurant");
	mysqli_set_charset($link,"utf8");
	
?>