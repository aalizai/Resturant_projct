<?php
	session_start();
	if($_SESSION['login']=="correct"){

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Restaurant</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />    
    <!-- full calendar css-->
    <link href="assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
	<link href="assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
    <!-- easy pie chart-->
    <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <!-- owl carousel -->
    <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
	<link href="css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
    <!-- Custom styles -->
	<link rel="stylesheet" href="css/fullcalendar.css">
	<link href="css/widgets.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
	<link href="css/xcharts.min.css" rel=" stylesheet">	
	<link href="css/jquery-ui-1.10.4.min.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/lte-ie7.js"></script>
    <![endif]-->
 </head>
  <body>
  <!-- container section start -->
  <section id="container" class="">
  <header class="header dark-bg">
      <?php
		  $menu="spend";
		  $sub ="add_spend";
		require_once("headerCom.php");
	    require_once("sidebar.php");
	  ?>
	  
	  <?php
		  require_once("connection.php");
		  if(isset($_POST['name'])){
			  
			  $name = $_POST['name'];
			  $date = $_POST['date'];
			  $salary = $_POST['salary'];
			  $info = $_POST['info'];
			  if(preg_match("/^[0-9]*$/",$salary)){
			  $save_data = mysqli_query($link,"INSERT INTO i_spend  (name,date,salary,info) VALUES ('$name','$date','$salary','$info')");
			  if($save_data){
				  $save = "<span style='color:lightblue'>Succesful saved</span>";
				  }else{
				  $save = "<span style='color:red'>Sorry a problem occurred!</span>";				
			  }
			  }else{
				  $save = "<span style='color:red'>Please check your salary input!</span>";								  
			  }
			  }
	  ?>
	  
      <!--sidebar end-->
   
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">            
              <!--overview start-->
			  <div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
						<li><i class="fa fa-list"></i>Expenses</li>
						<li><i class="icon_document_alt"></i><a href="add_spend.php">Add Expense</a></li>
						<li><i class="fa fa-laptop"></i>Page</li>						  	
					</ol>
				</div>
			  </div>
			
			 <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
						  <i class="fa fa-plus"></i>
								Add expense <?php if(!empty($save)){echo $save;}?>
                          </header>
						  
                          <div class="panel-body">
                              <table class="form col-lg-3">
                                  <form class="form-validate form-horizontal" id="feedback_form" method="post" action="">
                                      <tr class="form-group "> 
										<td for="cname" class="control-label col-lg-2">Name<span class="required"></span></td>									  
										  <td class="col-lg-3">
                                           <input class="form-control" name="name" type="text" required />
										  </td>
										</tr>
										
                                      <tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Date <span class="required"></span></td>
										  <td class="col-lg-3">
                                              <input class="form-control " type="date" name="date" required />
                                          </td>
                                      </tr>
									  
									  <tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Salary<span class="required"></span></td>
                                          <td class="col-lg-3">
                                              <input class="form-control " type="text" name="salary" />
                                          </td>
                                      </tr>
									
									<tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Information</td>
                                          <td class="col-lg-3">
                                              <textarea class="form-control " id="info" type="text" name="info"></textarea>
                                          </td>
                                      </tr>
                                     
									 
                                      <tr class="form-group">
											<td></td>
                                             <td class="col-lg-offset-1 col-lg-9">
												
												<button class="btn btn-primary" type="submit" name="submit">Save</button>
												<button class="btn btn-default" type ="button" >Cancel</button>
											  </td>
										</tr>
	
                                  </form>
								  
                              </table>

                          </div>
                      </section>
                  </div>
              </div>
              
          </section>
      </section>
      <!--main content end-->
  </section>
  <!-- container section start -->

  
    <!-- javascripts -->
    <script src="js/jquery.js"></script>
	<script src="js/jquery-ui-1.10.4.min.js"></script>
    <script src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <!-- bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- charts scripts -->
    <script src="assets/jquery-knob/js/jquery.knob.js"></script>
    <script src="js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="js/owl.carousel.js" ></script>
    <!-- jQuery full calendar -->
    <<script src="js/fullcalendar.min.js"></script> <!-- Full Google Calendar - Calendar -->
	<script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="js/calendar-custom.js"></script>
	<script src="js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="js/jquery.customSelect.min.js" ></script>
	<script src="assets/chart-master/Chart.js"></script>
   
    <!--custome script for all page-->
    <script src="js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
	<script src="js/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="js/jquery-jvectormap-world-mill-en.js"></script>
	<script src="js/xcharts.min.js"></script>
	<script src="js/jquery.autosize.min.js"></script>
	<script src="js/jquery.placeholder.min.js"></script>
	<script src="js/gdp-data.js"></script>	
	<script src="js/morris.min.js"></script>
	<script src="js/sparklines.js"></script>	
	<script src="js/charts.js"></script>
	<script src="js/jquery.slimscroll.min.js"></script>
	
	


  <script>

      //knob
      $(function() {
        $(".knob").knob({
          'draw' : function () { 
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
          $("#owl-slider").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });
	  
	  /* ---------- Map ---------- */
	$(function(){
	  $('#map').vectorMap({
	    map: 'world_mill_en',
	    series: {
	      regions: [{
	        values: gdpData,
	        scale: ['#000', '#000'],
	        normalizeFunction: 'polynomial'
	      }]
	    },
		backgroundColor: '#eef3f7',
	    onLabelShow: function(e, el, code){
	      el.html(el.html()+' (GDP - '+gdpData[code]+')');
	    }
	  });
	});
</script>


  </body>
</html>
	<?php }else{
		header("location:login.php");
	} ?>