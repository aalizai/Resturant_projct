﻿<?php
	session_start();
	if($_SESSION['login']=="correct"){

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Restaurant</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />    
    <!-- full calendar css-->
    <link href="assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
	<link href="assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
    <!-- easy pie chart-->
    <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <!-- owl carousel -->
    <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
	<link href="css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
    <!-- Custom styles -->
	<link rel="stylesheet" href="css/fullcalendar.css">
	<link href="css/widgets.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
	<link href="css/xcharts.min.css" rel=" stylesheet">	
	<link href="css/jquery-ui-1.10.4.min.css" rel="stylesheet">
   
	<script src="jquery-1.12.0.min.js"></script>

 </head>
  <body>
  <!-- container section start -->
  <section id="container" class="">
	<header class="header dark-bg">
      <?php
		$menu="staple";
		$sub ="add_staple";
		require_once("headerCom.php");
	    require_once("sidebar.php");
	    require_once("connection.php");

	?>
    
      
	  <?php
			if(isset($_POST['weight'])){
				
				$name_C = $_POST['name_C'];
				$type   = $_POST['type'];
				$date   = $_POST['date'];
				$weight = $_POST['weight'];
				$price  = $_POST['price'];
				$kind   = $_POST['kind'];
				$info   = $_POST['information'];
				
			if(preg_match("/^[0-9]*$/",$price) and preg_match("/^[0-9]*$/",$weight)){
				$money  = $price * $weight;
				
				if($name_C ==="Chose contract" || $type ==="Chose the type"){
					$error = "<span style ='color:red'>Please select type and contract!</span>";
				}else{
					$save_data = mysqli_query($link,"INSERT INTO staple (name_c,type,date,kind,weight,price,money,info) VALUES ('$name_C','$type','$date','$kind','$weight','$price','$money','$info')");
						if($save_data){
						   $save = "<span style ='color:lightblue'>Succeful saved!</span>";
						}else{
						$error= "<span style ='color:red'>Sorry not saved!</span>";
					    
						}
				}
					
			}else{
				$error= "<span style ='color:red'>Sorry wrong input!</span>";
			}
				
			}
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  ?>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">            
              <!--overview start-->
			  <div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
						<li><i class="fa fa-list"></i>Staple</li>
						<li><i class="icon_document_alt"></i><a href="add_staples.php">Add Staple</a></li>
						<li><i class="fa fa-laptop"></i>Page</li>						  	
					</ol>
				</div>
			  </div>
				
				
			  <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
							  <i class="fa fa-plus"></i>
							  Add Staple <?php if(!empty($error)){echo $error;} elseif(!empty($save)){echo $save;}?>
                          </header>
						  <div class="panel-body">
                              <table class="form">
                                  <form class="form-validate form-horizontal" id="feedback_form" method="post" action="">
									  
									  <tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Chose Contract <span class="required"></span></td>
										  <td class="col-lg-6" style="width:100px">
											  <select style="border-radius:5px;border:1px solid lightgray;height:40px" id="id_name" name="name_C">
												  <option>Chose contract</option>
												  <?php 
													  $get_contract = mysqli_query($link,"SELECT * FROM contract");
													  while($data=mysqli_fetch_assoc($get_contract)){
														  echo "<option>".$data['name']."</option>";
														  
													  }
												  ?>
											  </select>
										  </td>
										  <td><span style = "color:red"></span></td>
                                      </tr>
									  <tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Type weight <span class="required"></span></td>
										  <td class="col-lg-6" >
											  <select style="border-radius:5px;border:1px solid lightgray;height:40px" name ="type">
												  <option>Chose the type </option>
												  <option>Kg</option>
												  <option>else</option>
											  </select>
										  </td>
										  <td><span style = "color:red"></span></td>
									  </tr>
									 <tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Kind <span class="required"></span></td>
										  <td class="col-lg-4">
                                              <input class="form-control "  type="text" id="id" name="kind" />
                                          </td>
										  <td><span style = "color:red"></span></td>
                                      </tr>
									  
									  <tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Date<span class="required"></span></td>
                                          <td class="col-lg-4">
                                              <input class="form-control " type="date" name="date" required/>
                                          </td>
										  <td><span style = "color:red"></span></td>
                                      </tr>
									  
									  <tr class="form-group">
                                          <td for="cemail" class="control-label col-lg-4">Weight</td>
                                          <td class="col-lg-4">
                                              <input class="form-control" type="text" name="weight" required />
                                          </td>
										  <td><span style = "color:red"></span></td>
                                      </tr>
									  <tr class="form-group">
                                          <td for="cemail" class="control-label col-lg-4">Price</td>
                                          <td class="col-lg-4">
                                              <input class="form-control" type="text" name="price" required />
                                          </td>
										  <td><span style = "color:red"></span></td>
                                      </tr>
									  <tr class="form-group">
                                          <td for="cemail" class="control-label col-lg-4">Information</td>
                                          <td class="col-lg-4">
                                              <textarea class="form-control" name="information" ></textarea>
                                          </td>
										  <td><span style = "color:red"></span></td>
                                      </tr>
									
									  <tr class="form-group">
										  <td></td>
										  <td class="col-lg-offset-2 col-lg-5">
                                              <button class="btn btn-primary" type="submit" name="submit">Save</button>
											  <button class="btn btn-default" type="button">Cancel</button>
										  </td>
										</tr>
									 
                                  </form>
                              </table>
                          </div>
						  
                      </section>
                  </div>
              </div>
			 
              
          </section>
      </section>
      <!--main content end-->
  </section>
  <!-- container section start -->

  
    <!-- javascripts -->
    <script src="js/jquery.js"></script>
	<script src="js/jquery-ui-1.10.4.min.js"></script>
    <script src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <!-- bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- charts scripts -->
    <script src="assets/jquery-knob/js/jquery.knob.js"></script>
    <script src="js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="js/owl.carousel.js" ></script>
    <!-- jQuery full calendar -->
    <<script src="js/fullcalendar.min.js"></script> <!-- Full Google Calendar - Calendar -->
	<script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="js/calendar-custom.js"></script>
	<script src="js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="js/jquery.customSelect.min.js" ></script>
	<script src="assets/chart-master/Chart.js"></script>
   
    <!--custome script for all page-->
    <script src="js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
	<script src="js/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="js/jquery-jvectormap-world-mill-en.js"></script>
	<script src="js/xcharts.min.js"></script>
	<script src="js/jquery.autosize.min.js"></script>
	<script src="js/jquery.placeholder.min.js"></script>
	<script src="js/gdp-data.js"></script>	
	<script src="js/morris.min.js"></script>
	<script src="js/sparklines.js"></script>	
	<script src="js/charts.js"></script>
	<script src="js/jquery.slimscroll.min.js"></script>
  <script>

      //knob
      $(function() {
        $(".knob").knob({
          'draw' : function () { 
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
          $("#owl-slider").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });
	  
	  /* ---------- Map ---------- */
	$(function(){
	  $('#map').vectorMap({
	    map: 'world_mill_en',
	    series: {
	      regions: [{
	        values: gdpData,
	        scale: ['#000', '#000'],
	        normalizeFunction: 'polynomial'
	      }]
	    },
		backgroundColor: '#eef3f7',
	    onLabelShow: function(e, el, code){
	      el.html(el.html()+' (GDP - '+gdpData[code]+')');
	    }
	  });
	});



  </script>
	  <script>
		  $(document).ready(function(){
			  
			  $("#id_name").change(function(){
				  var id = $("#id_name").val();
				  
				  $.ajax({
					  type:"post",
					  url:"check_name.php",
					  data:{amount:id},
					  success:function(data){
						  $("#id").val(data);
					  }
				  });
			  });
			  
			  
		  });
	  </script>

  </body>
</html>
	<?php }else{
		header("location:login.php");
	} ?>