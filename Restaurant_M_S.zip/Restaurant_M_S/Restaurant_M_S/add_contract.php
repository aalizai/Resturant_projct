﻿<?php
	session_start();
	if($_SESSION['login']=="correct"){

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Restaurant</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />    
    <!-- full calendar css-->
    <link href="assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
	<link href="assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
    <!-- easy pie chart-->
    <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <!-- owl carousel -->
    <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
	<link href="css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
    <!-- Custom styles -->
	<link rel="stylesheet" href="css/fullcalendar.css">
	<link href="css/widgets.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
	<link href="css/xcharts.min.css" rel=" stylesheet">	
	<link href="css/jquery-ui-1.10.4.min.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/lte-ie7.js"></script>
    <![endif]-->
 

 </head>
  <body>
  <!-- container section start -->
  <section id="container" class="">
	<header class="header dark-bg">
      <?php
		$menu ="contract";
		$sub  ="add_contract";
		require_once("headerCom.php");
	    require_once("sidebar.php");
	  ?>
	  <?php
	require_once("connection.php");
	$errorC ="";
	$errorS ="";
	$date=$code=$name=$cname=$stamp=$preamble=$sava=$error_company="";
	if(isset($_POST['date'])){
	$date = $_POST['date'];
	$code = $_POST['code'];
	$name = $_POST['name_contract'];
	$cname= $_POST['companey_name'];
	$stamp= $_POST['stamp'];
	$preamble = $_POST['preamble'];
	
	$p1_query= "INSERT INTO contract(id,code,name,companyname,stamp,date,preamble) VALUES (null,'$code','$name','$cname','$stamp','$date','$preamble')";
	if($cname=="Chose company name" || $cname ==""){
		$sava = false;
	}else{
	$sava = mysqli_query($link,$p1_query);
	$cname="";
	}
	if($sava){
		$date=$code=$name=$cname=$stamp=$preamble="";
		$errorC = $errorS ="";
		echo "saved";
		$saved = "<span style='color:lightblue'>Successful saved!</span>";
	}
	else{	$error_company = "<h5> * please chose company!</h5>";
			$check1 =mysqli_query($link,"SELECT code FROM contract");
			$check2 =mysqli_query($link,"SELECT stamp FROM contract");
			while($get_check = mysqli_fetch_assoc($check1)){
			if($get_check['code']==$code){
				$errorC="<h5> * pleace try agin!</h5>";
			}
			
			}
			while($get_check= mysqli_fetch_assoc($check2)){
			if($get_check['stamp']==$stamp){
				$errorS ="<h5> * pleace try agin!</h5>";
			}
			}
			echo "not saved";
	}
	
	}
	else{
	
	 echo "First you moust chose company!.";
	
	}
	
?>

      <!--sidebar end-->
      
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">            
              <!--overview start-->
			  <div class="row">
				<div class="col-lg-12">
					<h3 class="page-header"><i class="fa fa-laptop"></i><span style='color:black'>R</span><span style='color:red'>M</span><span style='color:green'>S</span></h3>
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
						<li><i class="fa fa-list"></i>Contract</li>
						<li><i class="icon_document_alt"></i><a href="add_contract.php">Add contract</a></li>
						<li><i class="fa fa-laptop"></i>Page</li>						  	
					</ol>
				</div>
			  </div>
			
			 <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
						  <i class="fa fa-plus"></i>
								Add Contract <?php if(!empty($saved)){echo $saved;}?>
                          </header>
						  
                          <div class="panel-body">
                              <table class="form">
                                  <form class="form-validate form-horizontal" id="feedback_form" method="post" action="">
                                      <tr class="form-group "> 
										<td for="cname" class="control-label col-lg-2">Date<span class="required"></span></td>									  
										
                                           <td class="col-lg-5">
                                           <input class="form-control" id="data" name="date" type="date" required value="<?php if(!empty($date)){ echo $date;}?>"/>
										  </td>
										</tr>
										<tr><td></td><td></td></tr><tr><td></td><td></td></tr>
                                      <tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Code <span class="required"></span></td>
										  <td class="col-lg-4">
                                              <input class="form-control " id="code" type="text" name="code" required value="<?php if(empty($errorC)){ echo $code;}?>"/>
                                          </td>
										  <td><span style = "color:red"><?php if(!empty($errorC))  echo $errorC;?></span></td>
                                      </tr>
                                     <tr><td></td><td></td></tr><tr><td></td><td></td></tr>
									 
									  <tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Name<span class="required"></span></td>
                                          <td class="col-lg-4">
                                              <input class="form-control " id="name_contract" type="text" name="name_contract" required value="<?php if(!empty($name)){ echo $name;}?>"/>
                                          </td>
                                      </tr>
                                     <tr><td></td><td></td></tr><tr><td></td><td></td></tr>
									 
									 <tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Companey Name<span class="required"></span></td>
                                          <td class="col-lg-4">
                                                 <select class="btn btn-info" title="Bootstrap 3 themes generator" name = "companey_name">                                                 
                                                    <option  title="Bootstrap 3 themes generator"> Chose company name</option>
                                                   <?php
													$data = "SELECT cname FROM  companey";
													$comp = mysqli_query($link,$data);
													while($get_data = mysqli_fetch_assoc($comp)){
												    echo '<option  title="Bootstrap 3 themes generator">'.$get_data['cname'].'</option>';
													}
                                                   ?>
												 </select>
                                            
                                          </td>
										   <td><span style = "color:red"><?php if(!empty($error_company))  echo $error_company;?></span></td>
                                      </tr>
                                     <tr><td></td><td></td></tr><tr><td></td><td></td></tr>
									 
									  <tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Stamp<span class="required"></span></td>
                                          <td class="col-lg-4">
                                              <input class="form-control " id="stamp" type="text" name="stamp" required value="<?php if(empty($errorS)){ echo $stamp;}?>"/>
                                          </td>
										   <td><span style = "color:red"><?php if(!empty($errorS))  echo $errorS;?></span></td>
                                      </tr>
                                     <tr><td></td><td></td></tr><tr><td></td><td></td></tr>
									 
									 
								 <tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Preamble</td>
                                          <td class="col-lg-4">
                                              <textarea class="form-control " id="preamble" type="text" name="preamble"><?php if(!empty($preamble)){ echo $preamble;}?></textarea>
                                          </td>
                                      </tr>
                                     <tr><td></td><td></td></tr><tr><td></td><td></td></tr>
									 
                                      <tr class="form-group">
											<td></td>
                                             <td class="col-lg-offset-2 col-lg-5">
                                              <button class="btn btn-primary" type="submit" name="submit">Save</button>
											  <button class="btn btn-default" type="button">Cancel</button>
                                           </td>
                                      </tr>
									  <tr><td></td><td></td></tr><tr><td></td><td></td></tr>
									  
									 
									 
									  

                                  </form>
                              </table>

                          </div>
                      </section>
                  </div>
              </div>
              
          </section>
      </section>
      <!--main content end-->
  </section>
  <!-- container section start -->

  
    <!-- javascripts -->
    <script src="js/jquery.js"></script>
	<script src="js/jquery-ui-1.10.4.min.js"></script>
    <script src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <!-- bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- charts scripts -->
    <script src="assets/jquery-knob/js/jquery.knob.js"></script>
    <script src="js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="js/owl.carousel.js" ></script>
    <!-- jQuery full calendar -->
    <<script src="js/fullcalendar.min.js"></script> <!-- Full Google Calendar - Calendar -->
	<script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="js/calendar-custom.js"></script>
	<script src="js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="js/jquery.customSelect.min.js" ></script>
	<script src="assets/chart-master/Chart.js"></script>
   
    <!--custome script for all page-->
    <script src="js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
	<script src="js/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="js/jquery-jvectormap-world-mill-en.js"></script>
	<script src="js/xcharts.min.js"></script>
	<script src="js/jquery.autosize.min.js"></script>
	<script src="js/jquery.placeholder.min.js"></script>
	<script src="js/gdp-data.js"></script>	
	<script src="js/morris.min.js"></script>
	<script src="js/sparklines.js"></script>	
	<script src="js/charts.js"></script>
	<script src="js/jquery.slimscroll.min.js"></script>
  <script>

      //knob
      $(function() {
        $(".knob").knob({
          'draw' : function () { 
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
          $("#owl-slider").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });
	  
	  /* ---------- Map ---------- */
	$(function(){
	  $('#map').vectorMap({
	    map: 'world_mill_en',
	    series: {
	      regions: [{
	        values: gdpData,
	        scale: ['#000', '#000'],
	        normalizeFunction: 'polynomial'
	      }]
	    },
		backgroundColor: '#eef3f7',
	    onLabelShow: function(e, el, code){
	      el.html(el.html()+' (GDP - '+gdpData[code]+')');
	    }
	  });
	});



  </script>

  </body>
</html>
	<?php }else{
		header("location:login.php");
	} ?>
