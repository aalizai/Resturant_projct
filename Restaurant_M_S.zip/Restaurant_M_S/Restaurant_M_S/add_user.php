﻿<?php
	
	require_once("connection.php");
	session_start();
	
	if(isset($_POST['newn'])){
		$name =test_input($_POST['newn']);
		
		if(!preg_match("/^[a-zA-Zا-ی ]*$/",$name)){
	      echo "<span style = 'color:red'>special char not supported!</span>";
	   }
	   else{
			$_SESSION['name']=2;
	       }
		
	}
	
	
	$chek = mysqli_query($link,"SELECT * FROM login");
	
	if(isset($_POST['newp']) and $_POST['newp']!=''){
			
	$data=test_input($_POST['newp']);
	
	while($get_data = mysqli_fetch_assoc($chek)){
	if($get_data['password']==$data){
		echo "<span style='color:red'>Please change your password!</span>";
		$_SESSION['pass']=1;
	}
	else{
		$_SESSION['pass']=2;
		$_SESSION['data1']=$data;
	   }
	}
	
	
	 if(!preg_match("/^[a-zA-Z0-9]*$/",$data)){
		echo "<span style='color:red'>special char not supported!</span>";
		$_SESSION['pass1']=1;
	}
	
	else{
	    $_SESSION['pass1']=2;
		$_SESSION['data1']=$data;
	}
	
	
	
	}
	
	
    if(isset($_POST['newr']) and $_POST['newr']!=""){
	$datar=$_POST['newr'];
	$_SESSION['data2']=$datar;
	
    if($_SESSION['data2']==$_SESSION['data1']){
		echo "<span style='color:green'>Correct.</span>";
		$_SESSION['pass2']=2;
	}
	else{
	echo "<span style='color:red'>wrong!</span";
	   $_SESSION['pass2']=1;
	}
}




   if(isset($_POST['newe']) && $_POST['newe']!=""){
	$email=$_POST['newe'];
	
	while($get_data = mysqli_fetch_assoc($chek)){
	   if($get_data['email']!=$email){
		      $_SESSION['email']=2;
	   }
	   else{
	      echo "<span style='color:red'>you can not insert this email.</span>";
		  $_SESSION['email']=1;
	   }   
	   }
	if(filter_var($email,FILTER_VALIDATE_EMAIL)){
				$_SESSION['email1']=2;	
	  }
	  else{
		echo "<span style='color:red'>special char not supported.</span>";
		$_SESSION['email1']=1;
	  }
	  
		}

		if(isset($_POST['sumbit'])){
			$n=$_SESSION['name'];
			$p=$_SESSION['pass'];
			$p1=$_SESSION['pass1'];
			$p2=$_SESSION['pass2'];
			$e=$_SESSION['email'];
			$e1=$_SESSION['email1'];
			




	if($n==2 && $p==2 && $p1==2 && p2==2 && $e==2 && $e1==2){
					$namec  =$_POST['user'];
					$datac  =$_POST['pass'];
					$emailc =$_POST['email'];
					mysqli_query($link,"INSERT INTO login (name,password,email) VALUES ('$namec','$datac','$emailc')");
					$a=$_SESSION['name']=1;
					$b=$_SESSION['pass']=1;
					$c=$_SESSION['email']=1;
					header("localtion:login.php");
					//echo "a ".$a."<br>b ".$b."<br>b1 ".$b1."<br>b2 ".$b2."<br>c ".$c."<br>c1 ".$c1;
		
		}else{

	echo "not saved!";
}
}


	

	function test_input($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);		
		return $data;
	
	}


?>