<?php
	session_start();
	if($_SESSION['login']=="correct"){

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Restaurant</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />    
    <!-- full calendar css-->
    <link href="assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
	<link href="assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
    <!-- easy pie chart-->
    <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <!-- owl carousel -->
    <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
	<link href="css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
    <!-- Custom styles -->
	<link rel="stylesheet" href="css/fullcalendar.css">
	<link href="css/widgets.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
	<link href="css/xcharts.min.css" rel=" stylesheet">	
	<link href="css/jquery-ui-1.10.4.min.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/lte-ie7.js"></script>
    <![endif]-->
 <script>
	function Change(x){
		if(x=="Date"){
			document.getElementById('type').type="date";
			document.getElementById('op').value="ok";
		}else{
			document.getElementById('type').type="text";
			
		}
		
	}
	
	function Readeyprint(com){
		
		var all_reports = document.body.innerHTML;
		var div_reports = document.getElementById(com).innerHTML;
		document.body.innerHTML = div_reports;
		window.print();
		document.body.innerHTML = all_reports;
		}
	
	
 </script>
 
 

 </head>
  <body>
  <!-- container section start -->
  <section id="container" class="">
	<header class="header dark-bg">
      <?php
		$menu ="reports";
		$sub="all_reports";
		require_once("headerCom.php");
	    require_once("sidebar.php");
	    require_once("connection.php");
		
	  ?>


      <!--sidebar end-->
      
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">            
              <!--overview start-->
			  <div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
						<li><i class="fa fa-list"></i>Reports</li>
						<li><i class="icon_document_alt"></i><a href="all_reports.php">List reports</a></li>
						<li><i class="fa fa-laptop"></i>Page</li>						  	
					</ol>
				</div>
			  </div>
			  <?php 
		require_once("connection.php");
		
		?>
			
			 <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
						  <i class="fa fa-list"></i>
								List Reports
                          </header>
						  <?php
							  $total1=$total2=$total3=$total4=0;
							  $salary_payment = mysqli_query($link,"SELECT * FROM salary_payment order by id desc");
							  while($get_payment = mysqli_fetch_assoc($salary_payment)){
								  $total1=$get_payment['payment']+$total1;
							  }
							  
							  $spend = mysqli_query($link,"SELECT * FROM i_spend order by id desc");
							  while($get_spend = mysqli_fetch_assoc($spend)){
								  $total2=$get_spend['salary']+$total2;
							  }
							  
							  $Espend = mysqli_query($link,"SELECT * FROM contract_payment order by id desc");
							  while($get_Espend = mysqli_fetch_assoc($Espend)){
								  $total3=$get_Espend['payment']+$total3;
							  }
							  
							  $sales = mysqli_query($link,"SELECT * FROM salses order by id desc");
							  while($get_sales = mysqli_fetch_assoc($sales)){
								  $total4=$get_sales['price']+$total4;
							  }
						  $main_total = $total4-($total1+$total2+$total3);
						  $exp = $total1+$total2+$total3;
						  if($total4<=($total1+$total2+$total3)){
							  echo '<h4 style="margin-left:20px;"><span style="color:red;">Income</span>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Expenses</h4>';
							  echo '<h4 style="margin-left:20px;"><span style="color:red;">'.$total4."</span>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp".$exp.'AF</h4>';
							  echo '<h4 style="margin-left:20px;"><span style="color:red;">Disadvantage&nbsp= '.$main_total.'AF</span></h4>';
						  }else{
							  echo '<h4 style="margin-left:20px;"><span style="color:blue;">Income</span>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Expenses</h4>';
							  echo '<h4 style="margin-left:20px;"><span style="color:blue;">'.$total4."</span>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp".$exp.'AF</h4>';
							  echo '<h4 style="margin-left:20px;"><span style="color:lightblue;">Advantage&nbsp= '.$main_total.'AF</span></h4>';
						 }
						 
						
						  ?>
						   
						  <div class="panel-body table-responsive col-lg-3" style="background-color:white" id="sells">
							<h4><a onclick="Readeyprint('sells')" class="btn btn-info"><i class="fa fa-print">Print</i></a> Sells</h4>
							<table class="table table-hover">
								<tbody>
									<tr>
										<th>#</th>
										<th>Name</th>
										<th>price</th>
										<th>money</th>
									</tr>
									
									
										<?php 
										$sales = mysqli_query($link,"SELECT * FROM salses order by id desc");
										$total=0;
										$count=1;
										while($get_sales = mysqli_fetch_assoc($sales)){
											$id=$get_sales['id_food'];
											$food = mysqli_query($link,"SELECT * FROM food WHERE id ='$id'");
											$get_food=mysqli_fetch_assoc($food);
												echo '<tr><td>'.$count.'</td><td>'.$get_food['name'].'</td><td>'.$get_food['salary'].'</td><td>'.$get_sales['price'].'</td></tr>';
												$total=$get_sales['price']+$total;
											$count++;
										   }
										  
										  echo'<tr><td>Total</td><td>//</td><td>//</td><td>'.$total.'AF</td></tr>';
										?>
									 
								
								</tbody>
							</table>
						  </div> 
						  <div class="panel-body table-responsive col-lg-3" style="background-color:white" id="Contract Payment">
							  <h4><a onclick="Readeyprint('Contract Payment')" class="btn btn-info"><i class="fa fa-print">Print</i></a>Contract Payment</h4>
							  <table class="table table-hover">
								  <tbody>
									  <tr>
										  <th>#</th>
										  <th>Name_C</th>
										  <th>Date</th>
										  <th>Money</th>
										  <th>Payment</th>
									  </tr>
									  
									  
									  <?php 
										  $Espend = mysqli_query($link,"SELECT * FROM contract_payment order by id desc");
										  $total=0;
										  $count=1;
										  while($get_Espend = mysqli_fetch_assoc($Espend)){
											  echo '<tr><td>'.$count.'</td><td>'.$get_Espend['c_name'].'</td><td>'.$get_Espend['date'].'</td><td>'.$get_Espend['totalmoney'].'</td><td>'.$get_Espend['payment'].'</td></tr>';
											  $total=$get_Espend['payment']+$total;
											  $count++;
										  }
										  
										  echo'<tr><td>Total</td><td>//</td><td>//</td><td>//</td><td>'.$total.'AF</td></tr>';
									  ?>
									  
									  
								  </tbody>
							  </table>
							  
						  </div>
						 
						  
						  <div class="panel-body table-responsive col-lg-3" style="background-color:white" id="Internal Expenses">
							<h4><a onclick="Readeyprint('Internal Expenses')" class="btn btn-info"><i class="fa fa-print">Print</i></a>Internal Expenses</h4>
							<table class="table table-hover">
							<tbody>
									<tr>
										<th>#</th>
										<th>Name</th>
										<th>Date</th>
										<th>Payment</th>
								</tr>
								
								
								<?php 
									$spend = mysqli_query($link,"SELECT * FROM i_spend order by id desc");
									$total=0;
									$count=1;
									while($get_spend = mysqli_fetch_assoc($spend)){
										echo '<tr><td>'.$count.'</td><td>'.$get_spend['name'].'</td><td>'.$get_spend['date'].'</td><td>'.$get_spend['salary'].'</td></tr>';
										$total=$get_spend['salary']+$total;
										$count++;
									}
									
									echo'<tr><td>Total</td><td>//</td><td>//</td><td>'.$total.'AF</td></tr>';
								?>
								
								
							</tbody>
							</table>
						  
						  </div>
						 
						  <div class="panel-body table-responsive col-lg-3" style="background-color:white" id="Personnel Payment">
							  <h4><a onclick="Readeyprint('Personnel Payment')" class="btn btn-info"><i class="fa fa-print">Print</i></a>Personnel Payment</h4>
							  <table class="table table-hover">
								  <tr>
									  <th>#</th>
									  <th>Name</th>
									  <th>Salary</th>
									  <th>Payment</th>
								  </tr>
								  
								  
								  <?php 
									  $salary_payment = mysqli_query($link,"SELECT * FROM salary_payment order by id desc");
									  $total=0;
									  $count=1;
									  while($get_payment = mysqli_fetch_assoc($salary_payment)){
										  $id=$get_payment['id_personnel'];
										  $personnel = mysqli_query($link,"SELECT * FROM personnel WHERE id ='$id'");
										  $salary=mysqli_fetch_assoc($personnel);
										  echo '<tr><td>'.$count.'</td><td>'.$salary['name'].'</td><td>'.$salary['salary'].'</td><td>'.$get_payment['payment'].'</td></tr>';
										  $total=$get_payment['payment']+$total;
										  $count++;
									  }
									  
									  echo'<tr><td>Total</td><td>//</td><td>//</td><td>'.$total.'AF</td></tr>';
								  ?>
								  
								  
							  </tbody>
						  </table>
						  
					  </div> 
					  
						  
						  
                      </section>
                  </div>
			 
              </div>
              
          </section>
      </section>
      <!--main content end-->
  </section>
  <!-- container section start -->
    <!-- javascripts -->
    <script src="js/jquery.js"></script>
	<script src="js/jquery-ui-1.10.4.min.js"></script>
    <script src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <!-- bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- charts scripts -->
    <script src="assets/jquery-knob/js/jquery.knob.js"></script>
    <script src="js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="js/owl.carousel.js" ></script>
    <!-- jQuery full calendar -->
    <<script src="js/fullcalendar.min.js"></script> <!-- Full Google Calendar - Calendar -->
	<script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="js/calendar-custom.js"></script>
	<script src="js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="js/jquery.customSelect.min.js" ></script>
	<script src="assets/chart-master/Chart.js"></script>
   
    <!--custome script for all page-->
    <script src="js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
	<script src="js/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="js/jquery-jvectormap-world-mill-en.js"></script>
	<script src="js/xcharts.min.js"></script>
	<script src="js/jquery.autosize.min.js"></script>
	<script src="js/jquery.placeholder.min.js"></script>
	<script src="js/gdp-data.js"></script>	
	<script src="js/morris.min.js"></script>
	<script src="js/sparklines.js"></script>	
	<script src="js/charts.js"></script>
	<script src="js/jquery.slimscroll.min.js"></script>
  <script>

      //knob
      $(function() {
        $(".knob").knob({
          'draw' : function () { 
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
          $("#owl-slider").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });
	  
	  /* ---------- Map ---------- */
	$(function(){
	  $('#map').vectorMap({
	    map: 'world_mill_en',
	    series: {
	      regions: [{
	        values: gdpData,
	        scale: ['#000', '#000'],
	        normalizeFunction: 'polynomial'
	      }]
	    },
		backgroundColor: '#eef3f7',
	    onLabelShow: function(e, el, code){
	      el.html(el.html()+' (GDP - '+gdpData[code]+')');
	    }
	  });
	});

		
		

  </script>

  </body>
</html>
<?php }else{
	header("location:login.php");
} ?>