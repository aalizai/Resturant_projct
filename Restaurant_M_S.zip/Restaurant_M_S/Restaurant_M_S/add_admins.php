﻿<?php
	session_start();
	if($_SESSION['login']=="correct"){

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Restaurant</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />    
    <!-- full calendar css-->
    <link href="assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
	<link href="assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
    <!-- easy pie chart-->
    <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <!-- owl carousel -->
    <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
	<link href="css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
    <!-- Custom styles -->
	<link rel="stylesheet" href="css/fullcalendar.css">
	<link href="css/widgets.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
	<link href="css/xcharts.min.css" rel=" stylesheet">	
	<link href="css/jquery-ui-1.10.4.min.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/lte-ie7.js"></script>
    <![endif]-->
 

 </head>
  <body>
  <!-- container section start -->
  <section id="container" class="">
	<header class="header dark-bg">
      <?php
		$menu ="admin";
		$sub="add_admins";
		require_once("headerCom.php");
	    require_once("sidebar.php");
	  ?>


      <!--sidebar end-->
      
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">            
              <!--overview start-->
			  <div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
						<li><i class="fa fa-list"></i>Admins</li>
						<li><i class="icon_document_alt"></i><a href="add_admins.php">Add Admins</a></li>
						<li><i class="fa fa-laptop"></i>Page</li>						  	
					</ol>
				</div>
			  </div>
			  <?php 
			  
				  function check_password($data){
					  if(preg_match("/^[a-zA-Z0-9]*$/",$data)){
						  return true;
					  }
					  
					  else {
						  return false;
					  }
				  }
				  
		require_once("connection.php");
		$check_name=$check_email=$check_pass=$check_rpass=" ";
		$save_email=$save_pass=$db=$db1=$db_saved=$text_show="";
		
		
		if(isset($_POST['submit'])){
		$name  =$_POST['name'];
		$email =$_POST['email'];
		$pass  =$_POST['pass'];
		$rpass =$_POST['rpass'];
	
	
	
		$check_name =check_password($name);
		$check_pass =check_password($pass);
		
		if($pass == $rpass){
			$check_rpass =true;
		}else{
			$check_rpass=false;
		}
		
		
		
		if(filter_var($email,FILTER_VALIDATE_EMAIL)){
			$check_email=true;
		}else{
				$check_email=false;
		}

	$save_data = mysqli_query($link,"SELECT * FROM login");
		while($get_data = mysqli_fetch_assoc($save_data)){
			if($get_data['email']==$email){
				$db = false;
				$text_show="occure";
			}else{
				$db=true;
			}
		}
		
		
		
		
		}

		if($db==true && $check_name == true && $check_email==true  && $check_pass==true && $check_rpass==true){
			$enc_pass = sha1($pass);
		   $save_db=mysqli_query($link,"INSERT INTO login (name,password,email) VALUES ('$name','$enc_pass','$email')");
			if($save_db){
			$db_saved=true;
			
			}else{
				$db_saved=false;
				$text_show="occure";
			}
		   
		   }
		
		
		?>
			  
			  
			  
			  
			
			 <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
						  <i class="fa fa-plus"></i>
								Add Admins <?php for($i=0;$i<20;$i++){echo'&nbsp';} if($db==true && $db_saved==true){echo "<span style='color:lightgreen'>saved your admin.</span>";}else if(($db==false || $db_saved==false)&& !empty($text_show)){echo "<span style='color:red'>please check your fields.</span>";}?>
                          </header>
						  
                          <div class="panel-body">
                              <table class="form">
                                  <form class="form-validate form-horizontal" id="feedback_form" method="post" action="">
                                    <tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Name <span class="required"></span></td>
                                           <td class="col-lg-4">
                                              <input class="form-control " id="name_contract" type="text" name="name" required value="<?php if(($check_name == false || $check_pass == false || $check_email == false || $check_rpass ==false || $db==false) && !empty($name)){echo $name;}?>"/>
                                          </td>
										 <td><span style = "color:red"><?php if($check_name == false){echo "Plese check the field!";}?></span></td>
                                      </tr>
                                     <tr><td></td><td></td></tr><tr><td></td><td></td></tr>
						
									<tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Email <span class="required"></span></td>
                                          <td class="col-lg-4">
                                            
											<input class="form-control"  name = "email" type ="email" value="<?php if(($check_name == false || $check_pass == false || $check_email == false || $check_rpass ==false || $db==false) && !empty($email)){echo $email;}?>">                                                 
                                             
                                          </td>
										   <td><span style = "color:red"><?php if($check_email == false){echo "Plese check the field!";}?></span></td>
                                      </tr>
									 <tr><td></td><td></td></tr><tr><td></td><td></td></tr>
									 
									 <tr class="form-group ">
                                          <td for="cemail" class="control-label col-lg-2">Password<span class="required"></span></td>
                                          <td class="col-lg-4">
                                              <input class="form-control " type="password" name="pass" required value="<?php if(($check_name == false || $check_pass == false || $check_email == false || $check_rpass ==false || $db==false) && !empty($pass)){echo $pass;}?>"/>
                                          </td>
										   <td><span style = "color:red"><?php if($check_pass ==false){echo "Plese check the field!";}?></span></td>
                                      </tr>
                                     <tr><td></td><td></td></tr><tr><td></td><td></td></tr>
									 
									 <tr class="form-group">
                                          <td for="cemail" class="control-label col-lg-4">Rpassword</td>
                                          <td class="col-lg-4">
                                              <input class="form-control" type="password" name="rpass" required value="<?php if(($check_name == false || $check_pass == false || $check_email == false || $check_rpass ==false || $db==false) && !empty($rpass)){echo $rpass;}?>"/>
                                          </td>
										  <td><span style = "color:red"><?php if($check_rpass == false){echo "Plese check the field!";}?></span></td>
                                      </tr>
									   <tr><td></td><td></td></tr><tr><td></td><td></td></tr>
									   
									  <tr class="form-group">
											<td></td>
                                             <td class="col-lg-offset-2 col-lg-5">
                                              <button class="btn btn-primary" type="submit" name="submit">Save</button>
											  <button class="btn btn-default" type="button">Cancel</button>
                                           </td>
                                      </tr>
									  <tr><td></td><td></td></tr><tr><td></td><td></td></tr>
									  
									 
									 
									  

                                  </form>
                              </table>
                          </div>
                      </section>
                  </div>
              </div>
              
          </section>
      </section>
      <!--main content end-->
  </section>
  <!-- container section start -->
		
  
    <!-- javascripts -->
    <script src="js/jquery.js"></script>
	<script src="js/jquery-ui-1.10.4.min.js"></script>
    <script src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <!-- bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- charts scripts -->
    <script src="assets/jquery-knob/js/jquery.knob.js"></script>
    <script src="js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="js/owl.carousel.js" ></script>
    <!-- jQuery full calendar -->
    <<script src="js/fullcalendar.min.js"></script> <!-- Full Google Calendar - Calendar -->
	<script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="js/calendar-custom.js"></script>
	<script src="js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="js/jquery.customSelect.min.js" ></script>
	<script src="assets/chart-master/Chart.js"></script>
   
    <!--custome script for all page-->
    <script src="js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
	<script src="js/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="js/jquery-jvectormap-world-mill-en.js"></script>
	<script src="js/xcharts.min.js"></script>
	<script src="js/jquery.autosize.min.js"></script>
	<script src="js/jquery.placeholder.min.js"></script>
	<script src="js/gdp-data.js"></script>	
	<script src="js/morris.min.js"></script>
	<script src="js/sparklines.js"></script>	
	<script src="js/charts.js"></script>
	<script src="js/jquery.slimscroll.min.js"></script>
  <script>

      //knob
      $(function() {
        $(".knob").knob({
          'draw' : function () { 
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
          $("#owl-slider").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });
	  
	  /* ---------- Map ---------- */
	$(function(){
	  $('#map').vectorMap({
	    map: 'world_mill_en',
	    series: {
	      regions: [{
	        values: gdpData,
	        scale: ['#000', '#000'],
	        normalizeFunction: 'polynomial'
	      }]
	    },
		backgroundColor: '#eef3f7',
	    onLabelShow: function(e, el, code){
	      el.html(el.html()+' (GDP - '+gdpData[code]+')');
	    }
	  });
	});



  </script>

  </body>
</html>
	<?php }else{
		header("location:login.php");
	} ?>