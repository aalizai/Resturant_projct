﻿
<?php
	
	require_once("connection.php");
	
		$id = $_GET['id'];
		
	$send = mysqli_query($link,"DELETE FROM contract WHERE id ='$id'");
	
	if($send){
			header("location:list_contract.php?delete=true");
	}
	else{
	header("location:list_contract.php?delete=false");
	
	}
	

?>