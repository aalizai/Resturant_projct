﻿<?php
	session_start();
	if($_SESSION['login']=="correct"){

?>
<?php

	$_SESSION['data1']=0;
	$_SESSION['data2']=0;
	$_SESSION['name']=1;
	$_SESSION['pass']=1;
	$_SESSION['pass1']=1;
	$_SESSION['pass2']=1;
	$_SESSION['email']=1;
	$_SESSION['email1']=1;
?>
<head>
  <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet"/>
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet"/>
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet"/>
    <link href="css/font-awesome.css" rel="stylesheet"/>
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet"/>
	<script src="jquery-1.12.0.min.js"></script>
	<script src="jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>
</head>
<body class="login-img3-body">


<div class="container">
  <!-- Trigger the modal with a button -->
  <div class="login-form">        
        <div class="login-wrap">
            <p class="login-img"><i class="icon_lock_alt"></i></p>
           <button type="button" class="btn btn-primary btn-lg btn-block" data-toggle="modal" data-target="#myModal" id="myBtn1">add user</button>
           <button type="button" class="btn btn-info btn-lg btn-block" data-toggle="modal" data-target="#myModal">Remove user</button>
	</div>
	</div>
  <!-- Modal -->
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align:center;color:lightgray;">Regestertion form</h4>
        </div>
        <div class="modal-body">
          <form class="form-horizontal" role="form" method="post" action="add_user.php">
			<div class="form-group form-group-md">
				<label class="col-md-2 control-label" for="user">Username</label>
					<div class="col-md-5">
						<input class="form-control" type="text" id="user" name="user" required>
					</div>
				<label class="col-md-5 control-label" ><span id="show0"></span></label>
			</div>
			
			<div class="form-group form-group-md">
				<label class="col-md-2 control-label" for="pass">Password</label>
					<div class="col-md-5">
						<input class="form-control" type="password" id="pass" name="pass" required>
					</div>
				<label class="col-md-5 control-label" for="pass"><span id="show1"></span></label>
			</div>
			
			<div class="form-group form-gropu-md">
				<label class="col-md-2 control-label" for="rpass">Rpassword</label>
					<div class="col-md-5">
						<input class="form-control" type="password" id="rpass">
					</div>
			<label class="col-md-5 control-label" for="pass"><span id="show2"></span></label>
			</div>
			
			<div class="form-group form-group-md">
				<label class="col-md-2 control-label" for="email">Email </label>
					<div class="col-md-5">
						<input class="form-control" type="email" id="email" name="email" required>
					</div>
			   <label class="col-md-5 control-label" for="email"><span id="show3"></span></label>
			</div>
			
			<div class="form-group form-group-md">
				<label class="col-md-2 control-label" for="sub"></label>
					<div class="col-md-5">
						<input class="btn btn-primary btn-md-2" type="submit" data-dismiss="false" id="sub" name="sumbit" value="Save"/>
					</div>
		  </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

 </body>
 
 <script>
$(document).ready(function(){
    $("#myBtn1").click(function(){
        $("#myModal1").modal({backdrop: "static"});
    });
	
	$("#pass").keyup(function(){
			var nw = $("#pass").val();
			var rnw = $("#rpass").val();
			
			$.ajax({
				method:"POST",
				url:"add_user.php",
				data:{newp:nw},
				success:function(data){
					$("span#show1").html(data);
				}
			});
		});
		
		$("#rpass").keyup(function(){
			var rnw = $("#rpass").val();
			$.ajax({
				method:"POST",
				url:"add_user.php",
				data:{newr:rnw},
				success:function(data){
					$("span#show2").html(data);
				}
			});
			

		});
		
		
		$("#email").keyup(function(){
			var rnw = $("#email").val();
			$.ajax({
				method:"POST",
				url:"add_user.php",
				data:{newe:rnw},
				success:function(data){
					$("span#show3").html(data);
				}
			});
		});
		
			$("#email").select(function(){
			var rnw = $("#email").val();
			$.ajax({
				method:"POST",
				url:"add_user.php",
				data:{newe:rnw},
				success:function(data){
					$("span#show3").html(data);
				}
			});
		});
		
		
		$("#user").keyup(function(){
			var rnw = $("#user").val();
			$.ajax({
				method:"POST",
				url:"add_user.php",
				data:{newn:rnw},
				success:function(data){
					$("span#show0").html(data);
				}
			});
		});
		
		$("#user").select(function(){
			var rnw = $("#user").val();
			$.ajax({
				method:"POST",
				url:"add_user.php",
				data:{newn:rnw},
				success:function(data){
					$("span#show0").html(data);
				}
			});
		});
	
});
</script>

</html>
<?php }else{
	header("location:login.php");
} ?>